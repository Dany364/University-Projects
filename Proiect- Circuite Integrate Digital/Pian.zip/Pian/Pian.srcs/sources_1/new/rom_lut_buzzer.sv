module rom_lut_buzzer
(
    input logic [4:0] note,
    output logic [31:0] clock_cycles_needed
);

always_comb
begin
    case(note)
    0:
        begin
            clock_cycles_needed = 382219;
        end
     1:
        begin
            clock_cycles_needed = 360776;
        end
     2:
        begin
            clock_cycles_needed = 340530;
        end
     3:
        begin
            clock_cycles_needed = 321409;
        end
     4:
        begin
            clock_cycles_needed = 303361;
        end
     5:
        begin
            clock_cycles_needed = 286336;
        end
     6:
        begin
            clock_cycles_needed = 270270;
        end
     7:
        begin
            clock_cycles_needed = 255102;
        end
     8:
        begin
            clock_cycles_needed = 240789;
        end
     9:
        begin
            clock_cycles_needed = 227273;
        end
      10:
        begin
            clock_cycles_needed = 214519;
        end
     11:
        begin
            clock_cycles_needed = 202478;
        end
default: 
        begin
        clock_cycles_needed = 9999999;
        end
           
                 
    endcase
end
endmodule