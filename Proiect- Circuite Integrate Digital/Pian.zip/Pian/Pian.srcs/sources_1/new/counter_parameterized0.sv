module counter_parameterized0(
    input logic clk,
    input logic rst,
    input logic en,
    output logic [7:0] out
    );
    
    always_ff @(posedge clk) begin
    if(rst==1) out<=0;
    else if(en==1) out<=out+1;
        else out<=out;
    end
endmodule