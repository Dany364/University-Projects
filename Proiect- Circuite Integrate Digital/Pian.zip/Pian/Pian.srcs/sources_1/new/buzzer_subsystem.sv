module buzzer_subsystem(
    input logic clk, rst, 
    input logic [4:0] notes,
    output logic out
    );
    
logic [31:0] fir0;
logic [31:0] fir1;
logic fir2;
logic [31:0] fir3;
assign fir0 = fir3 >> 1;

comp_less_eq comp_less_eq_0
(
    .in0(fir0),
    .in1(fir1),
    .out(fir2)
);

counter counter_0
(
    .clk(clk),
    .rst(fir2|rst),
    .en(1),
    .out(fir1)
);

rom_lut_buzzer rom_lut_buzzer_0
(
    .note(notes),
    .clock_cycles_needed(fir3)
);

toggle_ff toggle_ff_0
(
    .clk(clk),
    .rst(rst),
    .toggle(fir2),
    .out(out) 
);
endmodule
