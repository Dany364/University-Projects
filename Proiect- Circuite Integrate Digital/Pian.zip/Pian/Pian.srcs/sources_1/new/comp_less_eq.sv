module comp_less_eq(
    input logic [31:0] in0,
    input logic [31:0] in1,
    output logic out
    );
    
    always_comb begin
    if(in0<=in1) out=1;
    else out=0;
    end
    
endmodule