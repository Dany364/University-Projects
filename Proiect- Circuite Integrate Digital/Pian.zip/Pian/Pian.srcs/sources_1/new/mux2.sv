module mux2(
    input logic [4:0] in0, in1,
    input logic sel,
    output logic [4:0] out
    );
    
    always_comb begin
    if(sel==0) out=in0;
    else out=in1;
    end
endmodule
