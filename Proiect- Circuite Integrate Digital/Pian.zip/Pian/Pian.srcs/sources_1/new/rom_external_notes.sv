module rom_external_notes(
    input logic [11:0] switches,
    output logic [4:0] notes
    );
    
    
    always_comb begin
    case(switches) 
    1:notes=5'd0;
    2:notes=5'd1;
    4:notes=5'd2;
    8:notes=5'd3;
    16:notes=5'd4;
    32:notes=5'd5;
    64:notes=5'd6;
    128:notes=5'd7;
    256:notes=5'd8;
    512:notes=5'd9;
    1024:notes=5'd10;
    2048:notes=5'd11;
    4096:notes=5'd12;
        
    default: notes=5'd31;
    endcase
    end
endmodule
