module leds_subsystem(
    input logic clk,
    input logic rst,
    input logic [4:0] notes,
    output logic out_to_ws2812b    
);

logic [23:0] data;
logic pulse;

FSM_leds(
    .clk(clk),
    .data_rgb(data),
    .rst(rst),
    .start(pulse),
    .out_to_ws2812b(out_to_ws2812b)
);

timer_variabil
#
(
    .timer_comp(10000)  
)
(
    .clk(clk),
    .rst(rst),
    .pulse(pulse)
);

rom_lut_leds(
    .addr(notes),
    .data(data)
);



endmodule
