module counter
(
    input logic clk,
    input logic rst,
    input logic en,
    output logic [31:0] out
);

always_ff @(posedge clk)
begin
    if(rst == 1)
        begin
            out <= 0;
        end
    else 
        begin
            if(en == 1)
                out <= out + 1;
            else 
                out <= out;    
        end
                
end
endmodule