module autoplay_subsystem(
    input logic clk, rst,
    output logic [4:0] notes
    );
       logic w_tmr;
    logic [7:0] w_cnt;
    
timer_variabil timer_variabil_0
(
    .clk(clk),
    .rst(rst),
    .pulse(w_tmr)
);

counter_parameterized0 counter_0(
    .clk(clk),
    .rst(rst),
    .en(w_tmr),
    .out(w_cnt)
);
    
rom_autoplay rom_autoplay_0(
    .addr(w_cnt),
    .data(notes)
);
endmodule
