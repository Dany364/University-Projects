module mux4_5b(
    input logic [4:0] in0, in1,in2,in3,
    input logic [1:0] sel,
    output logic [4:0] out
    );
    logic [4:0] w0,w1;
    mux2 mux0(
    .in0(in0),
    .in1(in1),
    .sel(sel[0]),
    .out(w0)
    );
    
    mux2 mux1(
    .in0(in2),
    .in1(in3),
    .sel(sel[0]),
    .out(w1)
    );
    
    mux2 mux2(
    .in0(w0),
    .in1(w1),
    .sel(sel[1]),
    .out(out)
    );
    
    
endmodule
