module comp_less_eq
(
    input logic [31:0] in0,
    input logic [31:0] in1,
    output logic out
);

assign out = (in0 <= in1) ? 1:0;
endmodule