module Top(
    input logic clk, rst,
    input logic [11:0] notes,
    input logic [1:0] mux_select,
    input logic [3:0] columns,
    output logic [3:0] lines,
    output logic buzzer_out, ws2812b_out,
    output logic [4:0] leds_for_testing
    );
    
    logic [4:0] w0,w1,w2,w4;
    
    rom_external_notes rom_external_notes_0 (
    .switches(notes),
    .notes(w0)
    );
    
    autoplay_subsystem autoplay_subsystem_0(
    .clk(clk),
    .rst(rst),
    .notes(w2)
    );
    
    mux4_5b mux4_5b_0(
    .in0(w0),
    .in1(w1),
    .in2(w2),
    .in3(5'd31),
    .sel(mux_select),
    .out(w4)
    );
    
    keyboard_subsystem keyboard_subsystem_0(
    .clk(clk),
    .rst(rst),
    .columns(columns),
    .lines(lines),
    .notes(w1)
    );
    
    buzzer_subsystem buzzer_subsystem_0(
    .clk(clk),
    .rst(rst),
    .notes(w4),
    .out(buzzer_out)
    );
    
    assign leds_for_testing=w4;
    
    leds_subsystem leds_subsystem_0(
    .clk(clk),
    .rst(rst),
    .notes(w4),
    .out_to_ws2812b(ws2812b_out)
    );
endmodule
