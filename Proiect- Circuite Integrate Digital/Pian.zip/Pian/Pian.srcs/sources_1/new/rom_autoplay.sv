module rom_autoplay(
    input logic [7:0] addr,
    output logic [4:0] data
    );

integer i;
logic [4:0] memorie_efectiva [0:255]; 
assign data=memorie_efectiva[addr];    
    initial
    begin
    memorie_efectiva[0]=31;
    memorie_efectiva[1]=31;
    memorie_efectiva[2]=31;
    memorie_efectiva[3]=31;
    memorie_efectiva[4]=4;
    memorie_efectiva[5]=3;
    memorie_efectiva[6]=4;
    memorie_efectiva[7]=3;
    memorie_efectiva[8]=4;
    memorie_efectiva[9]=11;
    memorie_efectiva[10]=3;
    memorie_efectiva[11]=0;
    memorie_efectiva[12]=9;
    memorie_efectiva[13]=9;
    memorie_efectiva[14]=9;
    memorie_efectiva[15]=0;
    memorie_efectiva[16]=4;
    memorie_efectiva[17]=9;
    memorie_efectiva[18]=11;
    memorie_efectiva[19]=11;
    memorie_efectiva[20]=11;
    memorie_efectiva[21]=4;
    memorie_efectiva[22]=8;
    memorie_efectiva[23]=11;
    memorie_efectiva[24]=0;
    memorie_efectiva[25]=0;
    memorie_efectiva[26]=0;
    memorie_efectiva[27]=0;
    memorie_efectiva[28]=4;
    memorie_efectiva[29]=3;
    memorie_efectiva[30]=4;
    memorie_efectiva[31]=3;
    memorie_efectiva[32]=4;
    memorie_efectiva[33]=11;
    memorie_efectiva[34]=2;
    memorie_efectiva[35]=0;
    memorie_efectiva[36]=9;
    memorie_efectiva[37]=9;
    memorie_efectiva[38]=0;
    memorie_efectiva[39]=4;
    memorie_efectiva[40]=9;
    memorie_efectiva[41]=11;
    memorie_efectiva[42]=11;
    memorie_efectiva[43]=11;
    memorie_efectiva[44]=4;
    memorie_efectiva[45]=0;
    memorie_efectiva[46]=11;
    memorie_efectiva[47]=9;
    memorie_efectiva[48]=9;
    memorie_efectiva[49]=9;
    memorie_efectiva[50]=31;
    memorie_efectiva[51]=31;
    
    
    
    for(i=52; i<1024; i++)
        memorie_efectiva[i]=31;    
    
    end


endmodule