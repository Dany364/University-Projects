module keyboard_subsystem(
    input logic clk, rst,
    input logic [3:0] columns,
    output logic [3:0] lines,
    output logic [4:0] notes
    );
localparam state_idle = 0;
localparam state_generate_line0 = 1;
localparam state_generate_line1 = 2;
localparam state_generate_line2 = 3;
localparam state_generate_line3 = 4;
localparam state_check_column0 = 5;
localparam state_check_column1 = 6;
localparam state_check_column2 = 7;
localparam state_check_column3 = 8;


logic [4:0] state, state_next;

always_ff @(posedge clk)
begin
    if(rst == 1)
        state <= state_idle;
    else 
        state <= state_next;
    
end


always_comb
begin
    state_next = state;
    lines = 4'b0000;
    
    case(state)
        state_idle: 
        begin
            state_next = state_generate_line0; 
        end
        
        state_generate_line0:
        begin
            lines = 4'b0001;
            state_next =  state_check_column0;
        end
        
        state_check_column0:
        begin
            
            state_next = state_check_column1;
        end
        
        state_check_column1:
        begin
            state_next = state_check_column2;
        end
        
        state_check_column2:
        begin
            state_next = state_check_column3;
        end
        
        state_check_column3:
        begin
           if(lines == 4'b0001) state_next = state_generate_line1; 
           else
           if(lines == 4'b0010) state_next = state_generate_line2;
           else
           if(lines == 4'b0100) state_next = state_generate_line3;
           else
           if(lines == 4'b1000) state_next = state_idle;
        end
        
        
        state_generate_line1:
        begin
            lines = 4'b0010;
            state_next = state_check_column0;
        end
        
        
        
        state_generate_line2:
        begin
            lines = 4'b0100;
            state_next = state_check_column0;
        end
        
      
        
        state_generate_line3:
        begin
            lines = 4'b1000;
            state_next = state_check_column0;
        end
        
      
       
        default: state_next = state_idle;
        
    endcase


end



always_ff@(posedge clk)
    begin
    if(rst == 1) 
        begin
        notes <= 31;
        end
    else
        begin
        case(state)
            state_idle:
                begin
               notes <= notes;
                end   
                
                
            state_generate_line0:
                begin
                notes <= notes;
                end
           
            state_generate_line1:
                begin
               notes <= notes;
                end
                
            state_generate_line2:
                begin
                notes <= notes;
                end
                
            state_generate_line3:
                begin
                notes <= notes;
                end
                
            state_check_column3:
                begin
                if(columns[3] == 1)
                    begin
                        if(lines == 4'b0001) notes <= 0;
                    else
                        if(lines == 4'b0010) notes <= 4;
                    else
                        if(lines == 4'b0100) notes <= 8;
                    else
                        if(lines == 4'b1000) notes <= 12;
                        
                    end
                end
                
            state_check_column2:
                begin
                if(columns[2] == 1)
                    begin
                        if(lines == 4'b0001) notes <= 1;
                    else
                        if(lines == 4'b0010) notes <= 5;
                    else
                        if(lines == 4'b0100) notes <= 9;
                    else
                        if(lines == 4'b1000) notes <= 13;
                        
                    end
                end
               
                
            state_check_column1:
                begin
                if(columns[1] == 1)
                    begin
                        if(lines == 4'b0001) notes <= 2;
                    else
                        if(lines == 4'b0010) notes <= 6;
                    else
                        if(lines == 4'b0100) notes <= 10;
                    else
                        if(lines == 4'b1000) notes <= 14;
                        
                    end
                end
                
                
            state_check_column0:
                begin
                if(columns[0] == 1)
                    begin
                        if(lines == 4'b0001) notes <= 3;
                    else
                        if(lines == 4'b0010) notes <= 7;
                    else
                        if(lines == 4'b0100) notes <= 11;
                    else
                        if(lines == 4'b1000) notes <= 15;
                        
                    end
                end
                
                
           
        
        endcase
        end
    end

endmodule
