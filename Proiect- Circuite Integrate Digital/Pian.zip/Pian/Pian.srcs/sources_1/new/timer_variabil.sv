module timer_variabil
#
(
parameter timer_comp = 300_000_00  
)
(
    input logic clk,
    input logic rst,
    output logic pulse
);


assign w_or = rst | pulse;
logic [31:0] w_cnt;

counter counter_0(
    .clk(clk),
    .rst(w_or),
    .en(1),
    .out(w_cnt)
    );
    
comp_less_eq comp_less_eq_0(
    .in0(timer_comp),
    .in1(w_cnt),
    .out(pulse)
    );
endmodule